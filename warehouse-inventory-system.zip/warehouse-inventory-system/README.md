# Warehouse Inventory System(WIS)

## Vision Statement
- [Vision Statement](https://code.cs.umanitoba.ca/winter-2022-a02/group-14/warehouse-inventory-system/-/blob/development/documentation/visionStatement.md) is documented here.

## Work Sheets
- [Iteration 1](https://code.cs.umanitoba.ca/winter-2022-a02/group-14/warehouse-inventory-system/-/blob/development/documentation/i1Worksheet.md) worksheet can be found here.
- [Iteration 2](https://code.cs.umanitoba.ca/winter-2022-a02/group-14/warehouse-inventory-system/-/blob/development/documentation/i2Worksheet.md) worksheet can be found here.
- [Iteration 3](https://code.cs.umanitoba.ca/winter-2022-a02/group-14/warehouse-inventory-system/-/blob/development/documentation/i3Worksheet.md) worksheet can be found here.

## Branching Strategy
-  [Branching strategy](https://code.cs.umanitoba.ca/winter-2022-a02/group-14/warehouse-inventory-system/-/blob/development/documentation/BranchingStrategy.md) is discussed in this document.

## Architecture
- The [architecture](https://code.cs.umanitoba.ca/winter-2022-a02/group-14/warehouse-inventory-system/-/blob/development/documentation/architecture.png) diagram can be found here.

## Retrospective
- The [retrospective](https://code.cs.umanitoba.ca/winter-2022-a02/group-14/warehouse-inventory-system/-/blob/development/documentation/RETROSPECTIVE.md) is discussed here.

## Contributors
- Kamarabbas Saiyed
- Alex Lannon
- Curtis McQuarrie
- Yuvraj Waraich
- Mansimar Bhasin

  


