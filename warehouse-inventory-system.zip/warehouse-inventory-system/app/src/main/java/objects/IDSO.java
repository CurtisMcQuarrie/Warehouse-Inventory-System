package objects;

public interface IDSO {
    public int getID();
}
